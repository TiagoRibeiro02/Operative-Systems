#define FIFO1 "/tmp/bruno_fifo.1"
#define FIFO2 "/tmp/bruno_fifo.2"
#define PERMS 0666
